package it.polimi.db2.project.controllers;

import java.io.IOException;

import javax.ejb.EJB;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringEscapeUtils;
import org.thymeleaf.TemplateEngine;

import it.polimi.db2.project.entities.*;
import it.polimi.db2.project.entities.Package;
import it.polimi.db2.project.exceptions.NullException;
import it.polimi.db2.project.services.*;

import java.util.ArrayList;
import java.util.List;

import org.thymeleaf.templatemode.TemplateMode;
import org.thymeleaf.templateresolver.ServletContextTemplateResolver;

@WebServlet("/ConfirmCreation")
public class ConfirmCreation extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private TemplateEngine templateEngine;
	@EJB(name = "it.polimi.db2.project.services/UserService")
	private UserService uService;
	@EJB(name = "it.polimi.db2.project.services/ServiceService")
	private ServiceService sService;
	@EJB(name = "it.polimi.db2.project.services/OrderService")
	private OrderService oService;
	@EJB(name = "it.polimi.db2.project.services/OptionalProjectService")
	private OptionalProjectService optService;
	@EJB(name = "it.polimi.db2.project.services/ValidityPeriodService")
	private ValidityPeriodService vService;
	@EJB(name = "it.polimi.db2.project.services/PackageService")
	private PackageService pService;

	public ConfirmCreation() {
		super();
		// TODO Auto-generated constructor stub
	}

	public void init() throws ServletException {
		ServletContext servletContext = getServletContext();
		ServletContextTemplateResolver templateResolver = new ServletContextTemplateResolver(servletContext);
		templateResolver.setTemplateMode(TemplateMode.HTML);
		this.templateEngine = new TemplateEngine();
		this.templateEngine.setTemplateResolver(templateResolver);
		templateResolver.setSuffix(".html");
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		User u = null;
		u = (User) request.getSession().getAttribute("userAdmin");
		
		// CREATE PACKAGE
		
		if (StringEscapeUtils.escapeJava(request.getParameter("packName")) != null) {
			String packName = null;
			List<Integer> optID = new ArrayList<Integer>();
			List<Service> services = new ArrayList<Service>();
			Package p = null;
			List<OptionalProduct> allOptProducts;
			
			packName = StringEscapeUtils.escapeJava(request.getParameter("packName"));
			
			allOptProducts = optService.findAll();
			for (int i = 0; i < allOptProducts.size(); i++) {
				if (request.getParameter(String.valueOf(allOptProducts.get(i).getId())) != null) {
					optID.add(allOptProducts.get(i).getId());
				}
			}

			try {
				p = pService.createPackage(packName, optID);
			} catch (NullException e) {
				response.sendError(HttpServletResponse.SC_BAD_REQUEST, "cannot create the package");
				return;
			}

			if (request.getParameter("12") != null) {
				int cost = Integer.parseInt(request.getParameter("cost1"));
				try {
					vService.createValidityPeriod(cost, 12, p.getId());
				} catch (NullException e) {
					response.sendError(HttpServletResponse.SC_BAD_REQUEST, "cannot create the validity");
					return;
				}
			}

			if (request.getParameter("24") != null) {
				int cost = Integer.parseInt(request.getParameter("cost2"));
				try {
					vService.createValidityPeriod(cost, 24, p.getId());
				} catch (NullException e) {
					response.sendError(HttpServletResponse.SC_BAD_REQUEST, "cannot create the validity");
					return;
				}
			}

			if (request.getParameter("36") != null) {
				int cost = Integer.parseInt(request.getParameter("cost3"));
				try {
					vService.createValidityPeriod(cost, 36, p.getId());
				} catch (NullException e) {
					response.sendError(HttpServletResponse.SC_BAD_REQUEST, "cannot create the validity");
					return;
				}
			}
			
			if (request.getParameter("fp") != null) {
				try {
					services.add(sService.createFixedPhone());
				} catch (NullException e) {
					response.sendError(HttpServletResponse.SC_BAD_REQUEST, "can't retrieve FixedPhone");
					return;
				}
			}

			if (request.getParameter("fi") != null) {
				try {
					int gb = Integer.parseInt(request.getParameter("fi-gb"));
					int gbFee = Integer.parseInt(request.getParameter("fi-gbFee"));

					services.add(sService.createFixedInternet(gb, gbFee, p));
				} catch (NullException e) {
					response.sendError(HttpServletResponse.SC_BAD_REQUEST, "can't retrieve FixedInternet");
					return;
				}
			}

			if (request.getParameter("mi") != null) {
				try {
					int gb = Integer.parseInt(request.getParameter("mi-gb"));
					int gbFee = Integer.parseInt(request.getParameter("mi-gbFee"));

					services.add(sService.createMobileInternet(gb, gbFee));
				} catch (NullException e) {
					response.sendError(HttpServletResponse.SC_BAD_REQUEST, "can't retrieve MobileInternet");
					return;
				}
			}

			if (request.getParameter("mp") != null) {
				try {
					int sms = Integer.parseInt(request.getParameter("mp-sms"));
					int min = Integer.parseInt(request.getParameter("mp-min"));
					int smsFee = Integer.parseInt(request.getParameter("mp-smsFee"));
					int minFee = Integer.parseInt(request.getParameter("mp-minFee"));

					services.add(sService.createMobilePhone(min, sms, minFee, smsFee));
				} catch (NullException e) {
					response.sendError(HttpServletResponse.SC_BAD_REQUEST, "can't retrieve MobilePhone");
					return;
				}
			}

		} else if (StringEscapeUtils.escapeJava(request.getParameter("optName"))!=null) {
			
			// CREATE OPTIONAL PRODUCT
			
			List<Package> allPackages = new ArrayList<Package>();
			List<Integer> packID = new ArrayList<Integer>();
			String optDescription = null;
			int monthlyFee = -1;
			
			String optName = StringEscapeUtils.escapeJava(request.getParameter("optName"));
	
			try {
				optDescription = StringEscapeUtils.escapeJava(request.getParameter("optDescription"));
				monthlyFee = Integer.parseInt(request.getParameter("optMonthlyFee"));				
			} catch (NullPointerException e) {
				response.sendError(HttpServletResponse.SC_BAD_REQUEST, "missing values");
				return;
			}
			
			allPackages = pService.findAll();
		
			for (int i = 0; i < allPackages.size(); i++) {
				if (request.getParameter(String.valueOf(allPackages.get(i).getId())) != null) {
					packID.add(allPackages.get(i).getId());
				}
			}
			
			if (packID.isEmpty() || packID == null) {
				response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Select at least one package");
				return;
			}
			
			try {
				optService.createOptProduct(optDescription, optName, monthlyFee, packID);
			} catch (NullException e) {
				response.sendError(HttpServletResponse.SC_BAD_REQUEST, "cannot create the package");
				return;
			}
			
			
		} else {
			response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Can't create anything");
			return;
		}
		
		

		request.getSession().setAttribute("user", u);
		String path = getServletContext().getContextPath() + "/GoToSalesReport";
		response.sendRedirect(path);

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
