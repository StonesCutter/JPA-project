package it.polimi.db2.project.controllers;

import java.io.IOException;

import javax.ejb.EJB;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.lang.StringEscapeUtils;

import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.WebContext;
import org.thymeleaf.templatemode.TemplateMode;
import org.thymeleaf.templateresolver.ServletContextTemplateResolver;

import it.polimi.db2.project.services.UserService;
import it.polimi.db2.project.entities.User;
import it.polimi.db2.project.exceptions.CredentialsException;
import javax.persistence.NonUniqueResultException;

@WebServlet("/CheckLogin")
public class CheckLogin extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private TemplateEngine templateEngine;
	@EJB(name = "it.polimi.db2.project.services/UserService")
	private UserService usrService;

	public CheckLogin() {
		super();
	}

	public void init() throws ServletException {
		ServletContext servletContext = getServletContext();
		ServletContextTemplateResolver templateResolver = new ServletContextTemplateResolver(servletContext);
		templateResolver.setTemplateMode(TemplateMode.HTML);
		this.templateEngine = new TemplateEngine();
		this.templateEngine.setTemplateResolver(templateResolver);
		templateResolver.setSuffix(".html");
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// obtain and escape params
		String email = null;
		String pwd = null;
		try {
			email = StringEscapeUtils.escapeJava(request.getParameter("email"));
			pwd = StringEscapeUtils.escapeJava(request.getParameter("pwd"));
			if (email == null || pwd == null || email.isEmpty() || pwd.isEmpty()) {
				throw new Exception("Missing or empty credential value");
			}

		} catch (Exception e) {
			// for debugging only e.printStackTrace();
			response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Missing credential value");
			return;
		}
		
		
		// query db to authenticate for user
		User user = null;
		String path;
		
		try {
			user = usrService.checkCredentials(email, pwd);
		} catch (NonUniqueResultException | CredentialsException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		if (user==null) {
			ServletContext servletContext = getServletContext();
			final WebContext ctx = new WebContext(request, response, servletContext, request.getLocale());
			ctx.setVariable("errorMsg", "Incorrect username or password");
			path = "/Index.html";
			templateEngine.process(path, ctx, response.getWriter());
		} else {
			if (user.getRole().equals("User")) {
				if (request.getSession().getAttribute("package")==null) {
					request.getSession().setAttribute("userCostumer", user);
					path = getServletContext().getContextPath() + "/GoToHomePage";
					response.sendRedirect(path);
				} else {
					request.getSession().setAttribute("userCostumer", user);
					path = getServletContext().getContextPath() + "/GoToCart";
					response.sendRedirect(path);
				}
				
			} else if (user.getRole().equals("Admin")) {
				request.getSession().setAttribute("userAdmin", user);
				path = getServletContext().getContextPath() + "/GoToHomeEmployee";
				response.sendRedirect(path);
			}			
		}
		
	}

	public void destroy() {
	}
}