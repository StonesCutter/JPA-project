package it.polimi.db2.project.controllers;

import java.io.IOException;

import javax.ejb.EJB;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.thymeleaf.TemplateEngine;

import it.polimi.db2.project.entities.*;
import it.polimi.db2.project.entities.Package;
import it.polimi.db2.project.services.*;

import java.util.List;
import org.thymeleaf.context.WebContext;
import org.thymeleaf.templatemode.TemplateMode;
import org.thymeleaf.templateresolver.ServletContextTemplateResolver;

@WebServlet("/GoToOrderPage")
public class GoToOrderPage extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private TemplateEngine templateEngine;
	@EJB(name = "it.polimi.db2.project.services/UserService")
	private UserService uService;
	@EJB(name = "it.polimi.db2.project.services/ServiceService")
	private ServiceService sService;
	@EJB(name = "it.polimi.db2.project.services/PackageService")
	private PackageService pService;
	@EJB(name = "it.polimi.db2.project.services/OrderService")
	private OrderService oService;
	@EJB(name = "it.polimi.db2.project.services/OptionalProjectService")
	private OptionalProjectService optService;
	@EJB(name = "it.polimi.db2.project.services/ValidityPeriodService")
	private ValidityPeriodService vService;

	public GoToOrderPage() {
		super();
		// TODO Auto-generated constructor stub
	}

	public void init() throws ServletException {
		ServletContext servletContext = getServletContext();
		ServletContextTemplateResolver templateResolver = new ServletContextTemplateResolver(servletContext);
		templateResolver.setTemplateMode(TemplateMode.HTML);
		this.templateEngine = new TemplateEngine();
		this.templateEngine.setTemplateResolver(templateResolver);
		templateResolver.setSuffix(".html");
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		User u = null;
		FixedInternet fiServices = null;
		FixedPhone fpServices = null;
		MobileInternet miServices = null;
		MobilePhone mpServices = null;
		List<OptionalProduct> optProducts = null;
		List<ValidityPeriod> validities = null;
		int packID = -1;
		boolean isBadRequest=false;
		Package p = null;

		u = (User) request.getSession().getAttribute("userCostumer");
		
		try {
			packID = Integer.parseInt(request.getParameter("packageID"));
			p = pService.findByID(packID);
			} catch (NumberFormatException | NullPointerException e) {
				isBadRequest = true;
			}
			if (isBadRequest) {
				response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Incorrect or missing package");
				return;
			}
		
		//prendo tutti i servizi offerti in quel pacchetto
		fiServices = sService.findFIByPackID(packID);
		fpServices = sService.findFPByPackID(packID);
		miServices = sService.findMIByPackID(packID);
		mpServices = sService.findMPByPackID(packID);
		
		//prendo tutti i validityPeriod per quel pacchetto
		validities = vService.findByPackID(packID);
		
		//prendo tutti gli OptionalProducts per quel pacchetto
		optProducts = optService.findByPackID(packID);

		String path = "productpage.html";
		ServletContext servletContext = getServletContext();
		final WebContext ctx = new WebContext(request, response, servletContext, request.getLocale());
		ctx.setVariable("fiServices", fiServices);
		ctx.setVariable("fpServices", fpServices);
		ctx.setVariable("miServices", miServices);
		ctx.setVariable("mpServices", mpServices);
		ctx.setVariable("validities", validities);
		ctx.setVariable("optProducts", optProducts);
		ctx.setVariable("user", u);
		ctx.setVariable("p", p);
		
		templateEngine.process(path, ctx, response.getWriter());
		
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
