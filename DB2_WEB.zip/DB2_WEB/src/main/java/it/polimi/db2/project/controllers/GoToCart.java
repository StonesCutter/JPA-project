package it.polimi.db2.project.controllers;

import java.io.IOException;

import javax.ejb.EJB;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.thymeleaf.TemplateEngine;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;

import it.polimi.db2.project.entities.*;
import it.polimi.db2.project.entities.Package;
import it.polimi.db2.project.services.*;

import java.util.ArrayList;
import java.util.List;
import org.thymeleaf.context.WebContext;
import org.thymeleaf.templatemode.TemplateMode;
import org.thymeleaf.templateresolver.ServletContextTemplateResolver;

@WebServlet("/GoToCart")
public class GoToCart extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private TemplateEngine templateEngine;
	@EJB(name = "it.polimi.db2.project.services/UserService")
	private UserService uService;
	@EJB(name = "it.polimi.db2.project.services/ServiceService")
	private ServiceService sService;
	@EJB(name = "it.polimi.db2.project.services/OrderService")
	private OrderService oService;
	@EJB(name = "it.polimi.db2.project.services/OptionalProjectService")
	private OptionalProjectService optService;
	@EJB(name = "it.polimi.db2.project.services/ValidityPeriodService")
	private ValidityPeriodService vService;
	@EJB(name = "it.polimi.db2.project.services/PackageService")
	private PackageService pService;

	public GoToCart() {
		super();
		// TODO Auto-generated constructor stub
	}

	public void init() throws ServletException {
		ServletContext servletContext = getServletContext();
		ServletContextTemplateResolver templateResolver = new ServletContextTemplateResolver(servletContext);
		templateResolver.setTemplateMode(TemplateMode.HTML);
		this.templateEngine = new TemplateEngine();
		this.templateEngine.setTemplateResolver(templateResolver);
		templateResolver.setSuffix(".html");
	}

	@SuppressWarnings("unchecked")
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		User u = null;
		List<OptionalProduct> allOptProducts = null; // contiene tutti gli optProd disponibili per quel pacchetto
		List<OptionalProduct> optProducts = new ArrayList<OptionalProduct>(); // contiene solo gli optProd selezionati
																				// dall'utente
		ValidityPeriod validity = null;
		int packID = -1;
		int validityID = -1;
		int totAmount = -1;
		Package p = null;
		LocalDate fromWhen = null;
		FixedInternet fiServices = null;
		FixedPhone fpServices = null;
		MobileInternet miServices = null;
		MobilePhone mpServices = null;
		HttpSession session = request.getSession();
		
		int OrderID = -1;

		u = (User) request.getSession().getAttribute("userCostumer");

		// dalla home abbiamo schiacciato il singolo ordine insoluto
		if (request.getParameter("orderID") != null) {
			OrderID = Integer.parseInt(request.getParameter("orderID"));
			Order o = oService.findById(OrderID);
			fiServices = sService.findFIByPackID(o.getPack().getId());
			fpServices = sService.findFPByPackID(o.getPack().getId());
			miServices = sService.findMIByPackID(o.getPack().getId());
			mpServices = sService.findMPByPackID(o.getPack().getId());
			String path = "cart.html";
			ServletContext servletContext = getServletContext();
			final WebContext ctx = new WebContext(request, response, servletContext, request.getLocale());
			ctx.setVariable("package", o.getPack());
			ctx.setVariable("validity", o.getPeriod());
			ctx.setVariable("totAmount", o.getTotalAmount());
			ctx.setVariable("optProducts", o.getOptProducts());
			ctx.setVariable("user", u);
			ctx.setVariable("fromWhen", o.getFromWhen());
			ctx.setVariable("fiServices", fiServices);
			ctx.setVariable("fpServices", fpServices);
			ctx.setVariable("miServices", miServices);
			ctx.setVariable("mpServices", mpServices);
			templateEngine.process(path, ctx, response.getWriter());
		} else {

			// non abbiamo ancora provato ad acquistare pacchetti
			if (session.getAttribute("package") == null) {
				try {
					packID = Integer.parseInt(request.getParameter("packageID"));
					p = pService.findByID(packID);
				} catch (NumberFormatException | NullPointerException e) {
					response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Incorrect or missing package");
					return;
				}

				try {
					validityID = Integer.parseInt(request.getParameter("validityID"));
					validity = vService.findByID(validityID);
				} catch (NumberFormatException | NullPointerException e) {
					response.sendError(HttpServletResponse.SC_BAD_REQUEST, "A validity period has to been chosed");
					return;
				}

				try {
					fromWhen = LocalDate.parse(request.getParameter("startDate"));
					if (fromWhen.isBefore(LocalDate.now())) {
						response.sendError(HttpServletResponse.SC_BAD_REQUEST,
								"You have to choose a valid starting date");
						return;
					}
				} catch (NumberFormatException | DateTimeParseException | NullPointerException e) {
					response.sendError(HttpServletResponse.SC_BAD_REQUEST,
							"Starting date is missing or the format isn't correct");
					return;
				}

				try {
					// prendo tutti gli OptProducts disponibili per quel pacchetto, e vedo se il
					// parametro passato ha come nome l'id di quel optProduct
					allOptProducts = optService.findByPackID(packID);
					for (int i = 0; i < allOptProducts.size(); i++) {
						if (request.getParameter(String.valueOf(allOptProducts.get(i).getId())) != null) {
							optProducts.add(allOptProducts.get(i));
						}
					}
				} catch (NumberFormatException | NullPointerException e) {
					// it is not mandatory
					optProducts = null;
				}

				// calcolo tot ordine
				int monthlyFee = validity.getMonthlyFee();
				if (optProducts != null) {
					for (int j = 0; j < optProducts.size(); j++) {
						monthlyFee = monthlyFee + optProducts.get(j).getMonthlyFee();
					}
				}
				totAmount = monthlyFee * validity.getMonths();

				fiServices = sService.findFIByPackID(packID);
				fpServices = sService.findFPByPackID(packID);
				miServices = sService.findMIByPackID(packID);
				mpServices = sService.findMPByPackID(packID);

			} else {

				// abbiamo provato ad acquistare quando non eravamo loggati, le info sono
				// salvate in sessione

				p = (Package) session.getAttribute("package");
				validity = (ValidityPeriod) session.getAttribute("validity");
				fromWhen = (LocalDate) session.getAttribute("fromWhen");
				totAmount = (int) session.getAttribute("totAmount");
				fiServices = (FixedInternet) session.getAttribute("fiServices");
				fpServices = (FixedPhone) session.getAttribute("fpServices");
				miServices = (MobileInternet) session.getAttribute("miServices");
				mpServices = (MobilePhone) session.getAttribute("mpServices");
				optProducts = (List<OptionalProduct>) session.getAttribute("optProducts");
			}

			if (u != null) {
				// siamo loggati, andiamo direttamente alla conferma dell'ordine
				String path = "cart.html";
				ServletContext servletContext = getServletContext();
				final WebContext ctx = new WebContext(request, response, servletContext, request.getLocale());
				ctx.setVariable("package", p);
				ctx.setVariable("validity", validity);
				ctx.setVariable("totAmount", totAmount);
				ctx.setVariable("optProducts", optProducts);
				ctx.setVariable("user", u);
				ctx.setVariable("fromWhen", fromWhen);
				ctx.setVariable("fiServices", fiServices);
				ctx.setVariable("fpServices", fpServices);
				ctx.setVariable("miServices", miServices);
				ctx.setVariable("mpServices", mpServices);

				templateEngine.process(path, ctx, response.getWriter());

			} else {
				// non siamo ancora loggati, salviamo le info in sessione
				String path = "Index.html";
				request.getSession().setAttribute("package", p);
				session.setAttribute("validity", validity);
				session.setAttribute("fromWhen", fromWhen);
				session.setAttribute("totAmount", totAmount);
				session.setAttribute("fiServices", fiServices);
				session.setAttribute("fpServices", fpServices);
				session.setAttribute("miServices", miServices);
				session.setAttribute("mpServices", mpServices);
				session.setAttribute("optProducts", optProducts);
				response.sendRedirect(path);

			}
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
