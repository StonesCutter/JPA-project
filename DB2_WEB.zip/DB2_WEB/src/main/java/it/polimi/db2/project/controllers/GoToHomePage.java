package it.polimi.db2.project.controllers;

import java.io.IOException;

import javax.ejb.EJB;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.thymeleaf.TemplateEngine;

import it.polimi.db2.project.entities.*;
import it.polimi.db2.project.entities.Package;
import it.polimi.db2.project.services.*;

import java.util.ArrayList;
import java.util.List;
import org.thymeleaf.context.WebContext;
import org.thymeleaf.templatemode.TemplateMode;
import org.thymeleaf.templateresolver.ServletContextTemplateResolver;

@WebServlet("/GoToHomePage")
public class GoToHomePage extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private TemplateEngine templateEngine;
	@EJB(name = "it.polimi.db2.project.services/UserService")
	private UserService uService;
	@EJB(name = "it.polimi.db2.project.services/PackageService")
	private PackageService pService;
	@EJB(name = "it.polimi.db2.project.services/OrderService")
	private OrderService oService;

	public GoToHomePage() {
		super();
		// TODO Auto-generated constructor stub
	}

	public void init() throws ServletException {
		ServletContext servletContext = getServletContext();
		ServletContextTemplateResolver templateResolver = new ServletContextTemplateResolver(servletContext);
		templateResolver.setTemplateMode(TemplateMode.HTML);
		this.templateEngine = new TemplateEngine();
		this.templateEngine.setTemplateResolver(templateResolver);
		templateResolver.setSuffix(".html");
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		User u = null;
		List<Package> packages = null;
		List<Order> orders = new ArrayList<Order>();
		List<Order> totOrders = null;

		u = (User) request.getSession().getAttribute("userCostumer");
		
		//aggiorno i valori della sessione
		if (u!=null) {
			u = uService.findByID(u.getId());
			request.getSession().setAttribute("userCostumer", u);
		}
		
		//prendo tutti i pacchetti offerti
		packages = pService.findAll();
		
		//se l'user è insolvent prendo tutti gli ordini rifiutati
		if (u!=null && u.getInsolvent()==true) {
			totOrders = oService.findByUser(u.getEmail());
			for (int i = 0; i < totOrders.size(); i++) {
				if (totOrders.get(i).getStatus() == false) {
					orders.add(totOrders.get(i));
				}
			}
		}

		String path = "Home.html";
		ServletContext servletContext = getServletContext();
		final WebContext ctx = new WebContext(request, response, servletContext, request.getLocale());
		ctx.setVariable("packages", packages);
		ctx.setVariable("user", u);
		ctx.setVariable("orders", orders);
		
		templateEngine.process(path, ctx, response.getWriter());
		
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
