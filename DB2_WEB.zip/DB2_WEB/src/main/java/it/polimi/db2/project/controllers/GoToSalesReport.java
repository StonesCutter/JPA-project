package it.polimi.db2.project.controllers;

import java.io.IOException;

import javax.ejb.EJB;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.thymeleaf.TemplateEngine;

import it.polimi.db2.project.entities.*;
import it.polimi.db2.project.services.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.thymeleaf.context.WebContext;
import org.thymeleaf.templatemode.TemplateMode;
import org.thymeleaf.templateresolver.ServletContextTemplateResolver;

@WebServlet("/GoToSalesReport")
public class GoToSalesReport extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private TemplateEngine templateEngine;
	@EJB(name = "it.polimi.db2.project.services/UserService")
	private UserService uService;
	@EJB(name = "it.polimi.db2.project.services/OrderService")
	private OrderService oService;
	@EJB(name = "it.polimi.db2.project.services/OptionalProjectService")
	private OptionalProjectService optService;
	@EJB(name = "it.polimi.db2.project.services/PackageService")
	private PackageService pService;
	@EJB(name = "it.polimi.db2.project.services/ReportService")
	private ReportService rService;
	@EJB(name = "it.polimi.db2.project.services/ValidityPeriodService")
	private ValidityPeriodService vService;
	@EJB(name = "it.polimi.db2.project.services/AlertService")
	private AlertService aService;

	public GoToSalesReport() {
		super();
		// TODO Auto-generated constructor stub
	}

	public void init() throws ServletException {
		ServletContext servletContext = getServletContext();
		ServletContextTemplateResolver templateResolver = new ServletContextTemplateResolver(servletContext);
		templateResolver.setTemplateMode(TemplateMode.HTML);
		this.templateEngine = new TemplateEngine();
		this.templateEngine.setTemplateResolver(templateResolver);
		templateResolver.setSuffix(".html");
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		List<ReportPack> byPack = rService.findPurchaseByPack();
		List<ReportPackValidity> byPackValidity = rService.findPurchaseByPackAndValidity();
		ReportOptProducts bSeller = rService.findBestSeller().get(0);
		String bestSellerName;
		int packID;
		int validityID;
		int validityMonths;
		int optID;
		String packName = null;
		Map<String, List<Integer>> numPurchaseByPack = new HashMap<String, List<Integer>>();
		Map<Map<String, Integer>, Integer> numPurchaseByPackValidity = new HashMap<Map<String, Integer>, Integer>();
		Map<String, Integer> bestSeller = new HashMap<String, Integer>();

		for (int i = 0; i < byPack.size(); i++) {
			packID = byPack.get(i).getIdPackage();
			packName = pService.findByID(packID).getPackageName();
			List<Integer> packPurch = new ArrayList<Integer>();
			packPurch.add(byPack.get(i).getNumPurchase());
			packPurch.add(byPack.get(i).getTotAmount());
			packPurch.add(byPack.get(i).getTotAmountWithoutOpt());
			packPurch.add((int) byPack.get(i).getAvgOptProducts());
			numPurchaseByPack.put(packName, packPurch); // associazione packName e numPurchase, totAmount,
														// totAmountWithoutOpt, avgOpt;
		}
		
		for (int i = 0; i < byPackValidity.size(); i++) {
			packID = byPackValidity.get(i).getIdPackage();
			packName = pService.findByID(packID).getPackageName();
			validityID = byPackValidity.get(i).getIdValidity();
			validityMonths = vService.findByID(validityID).getMonths();
			Map<String, Integer> packVal = new HashMap<String, Integer>();
			packVal.put(packName, validityID);
			numPurchaseByPackValidity.put(packVal, byPackValidity.get(i).getNumPurchase()); // associazione packName, validityMonths e numPurchase	
			
		} 

		optID = bSeller.getIdOptionalProduct();
		bestSellerName = optService.findByID(optID).getName();
		bestSeller.put(bestSellerName, bSeller.getSales());

		List<User> insolventUser = uService.findAllInsolvent();
		List<Order> rejectedOrders = oService.findAllRejected();
		List<Alert> alerts = aService.findAll();
		User u = (User) request.getSession().getAttribute("userAdmin");

		String path = "sales-report-page.html";
		ServletContext servletContext = getServletContext();
		final WebContext ctx = new WebContext(request, response, servletContext, request.getLocale());
		ctx.setVariable("insolvent", insolventUser);
		ctx.setVariable("rejOrders", rejectedOrders);
		ctx.setVariable("alerts", alerts);
		ctx.setVariable("purchaseByPack", numPurchaseByPack);
		ctx.setVariable("user", u);
		ctx.setVariable("purchaseByPackValidity", numPurchaseByPackValidity);
		ctx.setVariable("bestSeller", bestSeller);
		templateEngine.process(path, ctx, response.getWriter());

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
