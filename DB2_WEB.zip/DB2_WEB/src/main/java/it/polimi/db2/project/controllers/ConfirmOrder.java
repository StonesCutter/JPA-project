package it.polimi.db2.project.controllers;

import java.io.IOException;
import java.sql.Date;

import javax.ejb.EJB;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.thymeleaf.TemplateEngine;

import java.time.LocalDate;
import java.time.format.DateTimeParseException;

import it.polimi.db2.project.entities.*;
import it.polimi.db2.project.exceptions.NullException;
import it.polimi.db2.project.services.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import org.thymeleaf.templatemode.TemplateMode;
import org.thymeleaf.templateresolver.ServletContextTemplateResolver;

@WebServlet("/ConfirmOrder")
public class ConfirmOrder extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private TemplateEngine templateEngine;
	@EJB(name = "it.polimi.db2.project.services/UserService")
	private UserService uService;
	@EJB(name = "it.polimi.db2.project.services/ServiceService")
	private ServiceService sService;
	@EJB(name = "it.polimi.db2.project.services/OrderService")
	private OrderService oService;
	@EJB(name = "it.polimi.db2.project.services/OptionalProjectService")
	private OptionalProjectService optService;
	@EJB(name = "it.polimi.db2.project.services/ValidityPeriodService")
	private ValidityPeriodService vService;
	@EJB(name = "it.polimi.db2.project.services/PackageService")
	private PackageService pService;
	@EJB(name = "it.polimi.db2.project.services/AlertService")
	private AlertService aService;

	public ConfirmOrder() {
		super();
		// TODO Auto-generated constructor stub
	}

	public void init() throws ServletException {
		ServletContext servletContext = getServletContext();
		ServletContextTemplateResolver templateResolver = new ServletContextTemplateResolver(servletContext);
		templateResolver.setTemplateMode(TemplateMode.HTML);
		this.templateEngine = new TemplateEngine();
		this.templateEngine.setTemplateResolver(templateResolver);
		templateResolver.setSuffix(".html");
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		User u = null;
		List<OptionalProduct> allOptProducts = null; // contiene tutti gli optProd disponibili per quel pacchetto
		List<Integer> optProducts = new ArrayList<Integer>(); // contiene solo gli optProd selezionati dall'utente
		int totAmount = 0;
		int packID = -1;
		int validityID = -1;
		LocalDate fromWhen = null;
		Date date = null;
		Random rd = new Random(); // creating Random object
		//Boolean status = rd.nextBoolean(); // generate a random boolean for the payment
		Boolean status = true;
		//Boolean status = true;
		LocalDate d = LocalDate.now();
		Date now = Date.valueOf(d);

		u = (User) request.getSession().getAttribute("userCostumer");

		try {
			packID = Integer.parseInt(request.getParameter("packageID"));
		} catch (NumberFormatException | NullPointerException e) {
			response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Incorrect or missing package");
			return;
		}

		try {
			validityID = Integer.parseInt(request.getParameter("validityID"));
		} catch (NumberFormatException | NullPointerException e) {
			response.sendError(HttpServletResponse.SC_BAD_REQUEST, "A validity period has to been chosed");
			return;
		}

		try {
			fromWhen = LocalDate.parse(request.getParameter("fromWhen"));
			// trasforma da LocalDate a Date
			date = Date.valueOf(fromWhen);
		} catch (NumberFormatException | DateTimeParseException | NullPointerException e) {
			response.sendError(HttpServletResponse.SC_BAD_REQUEST,
					"Starting date is missing or the format isn't correct");
			return;
		}

		try {
			totAmount = Integer.parseInt(request.getParameter("totAmount"));
		} catch (NumberFormatException | NullPointerException e) {
			response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Missing total amount");
			return;
		}

		try {
			// prendo tutti gli OptProducts disponibili per quel pacchetto, e vedo se il
			// parametro passato ha come nome l'id di quel optProduct
			allOptProducts = optService.findByPackID(packID);
			for (int i = 0; i < allOptProducts.size(); i++) {
				if (request.getParameter(String.valueOf(allOptProducts.get(i).getId())) != null) {
					optProducts.add(allOptProducts.get(i).getId());
				}
			}
		} catch (NumberFormatException | NullPointerException e) {
			// it is not mandatory
			optProducts = null;
		}

		try {
			oService.createOrder(u.getId(), validityID, packID, date, totAmount, status, optProducts, now);
		} catch (NullException e) {
			response.sendError(HttpServletResponse.SC_BAD_REQUEST, "cannot create the order");
			return;
		}

		String path = getServletContext().getContextPath() + "/GoToHomePage";
		response.sendRedirect(path);

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
